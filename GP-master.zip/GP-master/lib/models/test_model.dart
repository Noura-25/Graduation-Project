class TestModel {
  String question;
  String image;
  Map<String, bool> answer;
  String colorBlind;

  //constractor
  TestModel(
    this.question,
    this.image,
    this.answer,
    this.colorBlind,
  );
}
